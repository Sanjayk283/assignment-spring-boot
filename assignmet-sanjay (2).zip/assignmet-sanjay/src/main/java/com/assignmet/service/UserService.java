package com.assignmet.service;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.assignmet.entities.User;
import com.assignmet.payload.CommentRequest;
import com.assignmet.payload.CommentResponse;
import com.assignmet.payload.LikeRequest;
import com.assignmet.payload.LikeResponse;
import com.assignmet.payload.PostLikeResponse;
import com.assignmet.payload.PostResponse;
import com.assignmet.payload.UserResponse;

public interface UserService {
	
	public UserResponse CreateUser(User user);

	//public UserResponse uploadPost(PostRequest postRequest,MultipartFile file,long id);

	public UserResponse uploadPost(String postRequest, MultipartFile file);

	//public UserResponse likeDislike(LikeAndDislikeRequest likeAndDislikeRequest);
	
	public LikeResponse likeDislike(LikeRequest likeRequest);

	public CommentResponse comment(CommentRequest commentRequest);

	public List<PostLikeResponse> getAllPostsBasedOnLikes();

	//public PostResponse getPostById(Long postId, Integer pageNumber, Integer pageSize, String sortBy);

	//public PostResponse getCommentByPostId(Long postId, Integer pageNumber, Integer pageSize, String sortBy);

	//public Pos getComment(Long postId, Integer pageNumber, Integer pageSize, String sortBy);

	public PostResponse getComment(Long postId, Integer pageNumber, Integer pageSize);

}
