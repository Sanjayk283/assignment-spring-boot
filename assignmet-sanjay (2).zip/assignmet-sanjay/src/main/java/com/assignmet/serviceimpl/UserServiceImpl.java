package com.assignmet.serviceimpl;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;
import com.assignmet.entities.Comment;
import com.assignmet.entities.Post;
import com.assignmet.entities.User;
import com.assignmet.exception.NotFoundException;
import com.assignmet.payload.CommentRequest;
import com.assignmet.payload.CommentResponse;
import com.assignmet.payload.LikeRequest;
import com.assignmet.payload.LikeResponse;
import com.assignmet.payload.PostLikeResponse;
import com.assignmet.payload.PostResponse;
import com.assignmet.payload.UserResponse;
import com.assignmet.repository.CommentRepository;
import com.assignmet.repository.PostRepository;
import com.assignmet.repository.UserRepository;
import com.assignmet.service.UserService;
import com.assignmet.utils.Constants;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class UserServiceImpl implements UserService{
	
	
	 @Value("${project.image}")
	 private String path;
	
	 @Value("${file}")
	 private String url;
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private PostRepository postRepository;
	
	@Autowired
	private CommentRepository commentRepository;

	/*
	 *API--- create user.
	 */
	
	@Override
	public UserResponse CreateUser(User user) {
		
		
		Optional<User> artistExists = userRepository.findByName(user.getName());
        UserResponse userResponse = new UserResponse();
	    if (artistExists.isPresent()) {
	    	userResponse.setData(artistExists.get());
	    	userResponse.setMessage(Constants.bad_request_message);
	    	userResponse.setStatus(Constants.bad_request);
	    } else {
	        // Save the artist entity into the database
	    	  User addUser = new User();
	    	  addUser.setUserId(user.getUserId());
	    	  addUser.setName(user.getName());
	    	  addUser.setCity(user.getCity());
	    	  addUser=userRepository.save(addUser);

	    	userResponse.setData(addUser);
	    	userResponse.setMessage(Constants.ok_message);
	    	userResponse.setStatus(Constants.ok);
	        log.info("Artist created: {}", user.getName());
	    }
	    return userResponse;
	}
	
	/*
	 * 
	 *API-- upload post( if post is image type then only support png, jpeg, jpg )
	 */
	@Override
	public UserResponse uploadPost(String postRequest, MultipartFile file) {
	    UserResponse userResponse = new UserResponse();
	    
	    // Check if the request payload is valid JSON
	    ObjectMapper objectMapper = new ObjectMapper();
	    User user;
	    try {
	        user = objectMapper.readValue(postRequest, User.class);
	    } catch (JsonProcessingException e) {
	        userResponse.setMessage(Constants.bad_request_message);
	        userResponse.setStatus(Constants.bad_request);
	        return userResponse;
	    }

	    // Check if the post data and file are valid
	    if (postRequest == null || file == null || file.isEmpty()) {
	        userResponse.setMessage("Invalid post data or file.");
	        userResponse.setStatus(HttpStatus.BAD_REQUEST.value());
	        return userResponse;
	    }

	    try {
	        String originalFilename = file.getOriginalFilename();
	        String fileExtension = StringUtils.getFilenameExtension(originalFilename);
	        List<String> allowedExtensions = Arrays.asList("jpg", "jpeg", "png");

	        if (!allowedExtensions.contains(fileExtension.toLowerCase())) {
	            userResponse.setMessage("Invalid file format. Only JPG, PNG, and JPEG formats are allowed.");
	            userResponse.setStatus(HttpStatus.BAD_REQUEST.value());
	            return userResponse;
	        }

	        // Generate a unique file name
	        String uniqueID = UUID.randomUUID().toString();
	        String fileName = uniqueID + "." + fileExtension;

	        // Full file path
	        String filePath = Paths.get(path, fileName).toString();

	        // Save the file
	        try (OutputStream outputStream = Files.newOutputStream(Paths.get(filePath))) {
	            outputStream.write(file.getBytes());
	        }

	        // Set post properties and save
	        Post post = new Post();
	        post.setFile(filePath);
	        post.setType(fileExtension);
	        // Map the user to the post
	        post.setUser(user);
	        postRepository.save(post);
            userResponse.setData(post);
	        userResponse.setMessage(Constants.ok_message);
	        userResponse.setStatus(Constants.ok);
	    } catch (IOException e) {
	        userResponse.setMessage(Constants.bad_request_message);
	        userResponse.setStatus(Constants.bad_request);
	    }

	    return userResponse;
	}
	/*
	 * API--like & dislike post(basis on postId)
	 * 
	 */

	@Override
	public LikeResponse likeDislike(LikeRequest likeRequest) {
	    Long postId = likeRequest.getPostId();

	    Optional<Post> optionalPost = postRepository.findById(postId);
	    if (optionalPost.isEmpty()) {
	        throw new NotFoundException("Post not found");
	    }
	    if(likeRequest.getLikeCount()==1&&likeRequest.getDislikeCount()==1) {
	    	 throw new NotFoundException("data mismatch");
	    }
	    
	    

	    Post post = optionalPost.get();
	    Integer likeCount = post.getLikeCount();
	    int currentLikes = likeCount != null ? likeCount.intValue() : 0;
        Integer dislikeCount = post.getDislikeCount();
	    int currentDislikes = dislikeCount != null ? dislikeCount.intValue() : 0;
        if (likeRequest.getLikeCount() == 1) {
	        post.setLikeCount(currentLikes + 1);
	    } else if (likeRequest.getDislikeCount() == 1) {
	        post.setDislikeCount(currentDislikes + 1);
	    } else {
	        throw new NotFoundException("Invalid action type");
	    }
	    // Save the updated post
	    postRepository.save(post);

	    // Create and return the response
	    LikeResponse likeResponse = new LikeResponse();
	    likeResponse.setPostId(post.getPostId());
	    likeResponse.setLike(post.getLikeCount());
	    likeResponse.setDislike(post.getDislikeCount());
	    return likeResponse;
	}
   /*
    * API-add or  updatecomment.(basis on postId)
    */

	@Override
	public CommentResponse comment(CommentRequest commentRequest) {
	    Optional<Post> findById = postRepository.findById(commentRequest.getPostId());

	    if (findById.isPresent()) {
	        if (commentRequest.getCommentId() == null) {
	            // Adding a new comment
	        	log.info("adding comment");
	            Comment comment = new Comment();
	            comment.setComment(commentRequest.getComment());
	            comment.setPost(findById.get());
	            User user = new User();
	            user.setUserId(commentRequest.getUserId());
	            comment.setUser(user);
	            log.info("saving comment");
	            Comment savedComment = commentRepository.save(comment);

	            CommentResponse commentResponse = new CommentResponse();
	            commentResponse.setComment(savedComment.getComment());
	            commentResponse.setPostId(savedComment.getPost().getPostId());
	            commentResponse.setUserId(savedComment.getUser().getUserId());
	            return commentResponse;
	        } else {
	            // Updating an existing comment
	        	log.info("updating comment");
	            Optional<Comment> findByCommentId = commentRepository.findById(commentRequest.getCommentId());
	            if (findByCommentId.isPresent()) {
	                Comment existingComment = findByCommentId.get();
	                existingComment.setComment(commentRequest.getComment());
	                Comment savedComment = commentRepository.save(existingComment);
                     
	                CommentResponse commentResponse = new CommentResponse();
	                commentResponse.setComment(savedComment.getComment());
	                commentResponse.setPostId(savedComment.getPost().getPostId());
	                commentResponse.setUserId(savedComment.getUser().getUserId());
	                return commentResponse;
	            } else {
	                throw new NotFoundException("Comment not found.");
	            }
	        }
	    } else {
	        throw new NotFoundException("Post not found.");
	    }
	}

	/*
	 * API---getAllComments(basis on postId),also apply pagination.
	 */

	@Override
	public PostResponse getComment(Long postId, Integer pageNumber, Integer pageSize) {
	    Pageable pageable = PageRequest.of(pageNumber, pageSize);
	    PostResponse postResponse = new PostResponse();
	    Optional<Post> userPostOptional = postRepository.findById(postId);

	    if (userPostOptional.isPresent()) {
	        Page<Comment> commentPage = commentRepository.findByPostId(postId, pageable);

	        postResponse.setPostId(postId);
	        postResponse.setComment(commentPage.getContent());
	        log.info("Comments fetched successfully for postId: {}", postId);
	        return postResponse;
	    } else {
	        log.error("Data not found for postId: {}", postId);

	        throw new NotFoundException("Data not found");
	    }
	}

	
/*
 *API- getAllPost(basis on like decreasing order)count total like,dislike & comment count.
 * 
 */
	@Override
	public List<PostLikeResponse> getAllPostsBasedOnLikes() {
	    try {
	        // Retrieve all posts from the repository, ordered by like count in descending order
	        List<Post> posts = postRepository.findAllByOrderByLikeCountDesc();

	        // Prepare the response list
	        List<PostLikeResponse> responseList = new ArrayList<>();

	        // Iterate over each post and populate the response
	        for (Post post : posts) {
	            // Calculate total likes, dislikes, and comments for each post
	            int totalLikes = post.getLikeCount() != null ? post.getLikeCount() : 0;
	            int totalDislikes = post.getDislikeCount() != null ? post.getDislikeCount() : 0;
	            int totalComments = commentRepository.countByPost(post);

	            // Create a response object and populate its fields
	            PostLikeResponse response = new PostLikeResponse();
	            response.setFile(post.getFile());
	            response.setType(post.getType());
	            response.setPostId(post.getPostId());
	            response.setTotalLikes(totalLikes);
	            response.setTotalDislikes(totalDislikes);
	            response.setTotalComments(totalComments);

	            // Add the response object to the list
	            responseList.add(response);
	        }

	        // Return the response list
	        return responseList;
	    } catch (NotFoundException e) {
	        // Log the exception and throw a custom exception or rethrow the original exception if needed
	        log.error("An error occurred while retrieving posts based on likes", e);
	        throw new NotFoundException("Failed to retrieve posts based on likes");
	    }
	}

}
