package com.assignmet.repository;


import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.assignmet.entities.Comment;
import com.assignmet.entities.Post;
@Repository
public interface CommentRepository extends JpaRepository<Comment, Long>{


	
	@Query(value = "select * from comment where post_id = :postId",nativeQuery = true)
	public Page<Comment> findByPostId(@Param("postId") Long postId, Pageable pageable);

	 public int countByPost(Post post);


}
