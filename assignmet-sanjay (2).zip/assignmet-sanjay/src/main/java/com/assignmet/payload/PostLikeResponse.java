package com.assignmet.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PostLikeResponse {

	private Long postId;
	private String type;
	private String file;
    private Integer totalLikes;
    private Integer totalDislikes;
    private Integer totalComments;

    
}
