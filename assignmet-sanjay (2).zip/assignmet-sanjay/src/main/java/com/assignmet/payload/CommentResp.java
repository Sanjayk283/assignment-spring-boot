package com.assignmet.payload;

import lombok.Data;

@Data
public class CommentResp {
	
	private  String comment;

}
