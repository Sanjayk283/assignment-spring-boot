package com.assignmet.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.assignmet.entities.User;
import com.assignmet.payload.CommentRequest;
import com.assignmet.payload.CommentResponse;
import com.assignmet.payload.LikeRequest;
import com.assignmet.payload.LikeResponse;
import com.assignmet.payload.PostLikeResponse;
import com.assignmet.payload.PostResponse;
import com.assignmet.payload.UserResponse;
import com.assignmet.service.UserService;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@RestController
@RequestMapping("/User")
public class UserController {

	@Autowired
	private UserService userService;
	
	@PostMapping("/createUser")
	public ResponseEntity<UserResponse> createUser(@RequestBody User user) {
        try {
            UserResponse createUserResponse = userService.CreateUser(user);
            log.info("User created successfully: {}", createUserResponse);
            return ResponseEntity.ok(createUserResponse);
        } catch (Exception e) {
            log.error("Error creating user: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
	
	@PostMapping(value = "/uploadpost", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<UserResponse> uploadpost(@RequestPart String postRequest,@RequestPart MultipartFile file){
		     UserResponse uploadPost = userService.uploadPost(postRequest,file);
		     return ResponseEntity.ok(uploadPost);
	}
	
	
	@PostMapping("/likeanddislike")
	public ResponseEntity<LikeResponse> likeDislike(@RequestBody  LikeRequest likeRequest){
	       LikeResponse likeDislike = userService.likeDislike(likeRequest);
	       return ResponseEntity.ok(likeDislike);
	}
	
	@PostMapping("/addComment")
	public ResponseEntity<CommentResponse> comment( @RequestBody CommentRequest commentRequest ){
		  CommentResponse comment = userService.comment(commentRequest);
		  return ResponseEntity.ok(comment);
	}
	
	@GetMapping("/getAllPostsBasedOnLikes")
    public List<PostLikeResponse> getAllPostsBasedOnLikes() {
        return userService.getAllPostsBasedOnLikes();
    }
	
	
	@GetMapping("/getAllComment/{postId}")
    public ResponseEntity<PostResponse> getCommentByPostId(@PathVariable Long postId,
    		@RequestParam(defaultValue = "0") Integer pageNumber,
            @RequestParam(defaultValue = "10") Integer pageSize){

         return ResponseEntity.ok(this.userService.getComment(postId,pageNumber, pageSize));

    }
	

}
