package com.assignmet.utils;

public class Constants {

	public static final Integer ok=200;
	public static final Integer bad_request=400;
	public static final Integer not_found=404;
	public static final String  ok_message="ok";
	public static final String bad_request_message="bad request";
    public static final String not_found_message="data not found";
}
